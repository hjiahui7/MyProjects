|---------------------------------------------------------------------------|
|  Title       | area triangle calculator using three ages or height and width(2 mods)
|---------------------------------------------------------------------------|              
|  Author(s)   | Jiahui Huang<hjiahui7>  Huanbo Fu<huanbof>
|---------------------------------------------------------------------------|              
|  Description | can calculator triangle area
|---------------------------------------------------------------------------|

Full Feature Set:
   there are two mods, one is mod1 which use three ages, the second one is mod2 using height and width


Notes:
   - This plugin requires that the shell support the process_builtin hook.

example:
areaTriCal mod1 10 10 10
or
areaTriCal mod2 10 10
