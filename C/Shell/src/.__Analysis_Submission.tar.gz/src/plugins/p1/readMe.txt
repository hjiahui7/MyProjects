|---------------------------------------------------------------------------|
|  Title       | Number changer
|---------------------------------------------------------------------------|              
|  Author(s)   | Jiahui Huang<hjiahui7>  Huanbo Fu<huanbof>
|---------------------------------------------------------------------------|              
|  Description | Can change decimal to binary or hex
|---------------------------------------------------------------------------|

Full Feature Set:
   change decimal to binary or hex, and result will show in the terminal.


Notes:
   - This plugin requires that the shell support the process_builtin hook.

example:
numchanger binary 10
or
numchanger hex 10
